#if defined(_GLFW_X11) || defined(_GLFW_WAYLAND)
	#include "glfw/src/xkb_unicode.c"
#endif

