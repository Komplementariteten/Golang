#if defined(_GLFW_X11) || defined(_GLFW_WAYLAND)
	#include "glfw/src/posix_time.c"
#endif

